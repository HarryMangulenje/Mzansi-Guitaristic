' HaMrex POS Installer v3.3
' Harry Mangulenje - South Africa
' Pure ASCII - No nested quotes - No PowerShell

Dim fso, sh, srcDir, idir, isAdmin
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
srcDir = fso.GetParentFolderName(WScript.ScriptFullName)

Sub MkDir(p)
    Dim parts, cur, i
    parts = Split(p, "\")
    cur = parts(0)
    For i = 1 To UBound(parts)
        cur = cur & "\" & parts(i)
        If Not fso.FolderExists(cur) Then
            On Error Resume Next
            fso.CreateFolder cur
            On Error GoTo 0
        End If
    Next
End Sub

Function DecodeBase64(b64)
    Dim xml, node
    Set xml = CreateObject("MSXML2.DOMDocument")
    Set node = xml.createElement("b64")
    node.DataType = "bin.base64"
    node.Text = b64
    DecodeBase64 = node.NodeTypedValue
End Function

' Detect admin
isAdmin = False
Dim tp
tp = sh.ExpandEnvironmentStrings("%PROGRAMFILES%") & "\HaMrexTmp"
On Error Resume Next
fso.CreateFolder tp
If Err.Number = 0 Then
    fso.DeleteFolder tp, True
    isAdmin = True
End If
Err.Clear
On Error GoTo 0

If isAdmin Then
    idir = sh.ExpandEnvironmentStrings("%PROGRAMFILES%") & "\HaMrexPOS"
    WScript.Echo "  Admin install -> " & idir
Else
    idir = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\HaMrexPOS"
    WScript.Echo "  User install  -> " & idir
End If
MkDir idir

' Copy HTML
WScript.Echo "  Copying app..."
Dim srcH, dstH
srcH = srcDir & "\HaMrex-POS.html"
dstH = idir & "\HaMrex-POS.html"
If Not fso.FileExists(srcH) Then
    MsgBox "Missing: HaMrex-POS.html", 16, "HaMrex POS"
    WScript.Quit 1
End If
On Error Resume Next
fso.CopyFile srcH, dstH, True
If Err.Number <> 0 Then
    MsgBox "Copy failed: " & Err.Description, 16, "HaMrex POS"
    WScript.Quit 1
End If
On Error GoTo 0
WScript.Echo "  App copied OK."

' Copy launcher VBS (shipped in ZIP - no runtime generation)
WScript.Echo "  Copying launcher..."
Dim srcL, dstL
srcL = srcDir & "\launcher.vbs"
dstL = idir & "\HaMrex POS.vbs"
If Not fso.FileExists(srcL) Then
    MsgBox "Missing: launcher.vbs", 16, "HaMrex POS"
    WScript.Quit 1
End If
fso.CopyFile srcL, dstL, True
WScript.Echo "  Launcher copied OK."

' Decode icon
WScript.Echo "  Decoding icon..."
Dim icoSrc, icoDst, icoOk, icoStr
icoSrc = srcDir & "\HaMrex.ico.b64"
icoDst = idir & "\HaMrex.ico"
icoOk = False
If fso.FileExists(icoSrc) Then
    On Error Resume Next
    Dim fh, b64, ln
    Set fh = fso.OpenTextFile(icoSrc, 1)
    b64 = ""
    Do While Not fh.AtEndOfStream
        ln = Trim(fh.ReadLine())
        If ln <> "" Then b64 = b64 & ln
    Loop
    fh.Close
    Dim st
    Set st = CreateObject("ADODB.Stream")
    st.Type = 1
    st.Open
    st.Write DecodeBase64(b64)
    st.SaveToFile icoDst, 2
    st.Close
    If Err.Number = 0 Then
        icoOk = True
        WScript.Echo "  Icon OK."
    Else
        WScript.Echo "  Icon skipped: " & Err.Description
        Err.Clear
    End If
    On Error GoTo 0
End If
If icoOk Then
    icoStr = icoDst
Else
    icoStr = "shell32.dll,22"
End If

' Write uninstaller
WScript.Echo "  Writing uninstaller..."
Dim uPath, uf
uPath = idir & "\Uninstall.bat"
Set uf = fso.CreateTextFile(uPath, True, False)
uf.WriteLine "@echo off"
uf.WriteLine "title Uninstall HaMrex POS"
uf.WriteLine "echo Removing HaMrex POS..."
uf.WriteLine "del /f /q " & Chr(34) & idir & "\HaMrex POS.vbs" & Chr(34)
uf.WriteLine "del /f /q " & Chr(34) & idir & "\HaMrex-POS.html" & Chr(34)
uf.WriteLine "del /f /q " & Chr(34) & idir & "\HaMrex.ico" & Chr(34)
uf.WriteLine "del /f /q " & Chr(34) & idir & "\Uninstall.bat" & Chr(34)
uf.WriteLine "reg delete HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\HaMrexPOS /f >nul 2>&1"
uf.WriteLine "echo Done. Data at %USERPROFILE%\HaMrexPOS preserved."
uf.WriteLine "pause"
uf.Close
WScript.Echo "  Uninstaller written."

' Create shortcuts
WScript.Echo "  Creating shortcuts..."
Dim p1, p2, sc
p1 = sh.ExpandEnvironmentStrings("%PUBLIC%") & "\Desktop\HaMrex POS.lnk"
p2 = sh.ExpandEnvironmentStrings("%USERPROFILE%") & "\Desktop\HaMrex POS.lnk"
On Error Resume Next
Set sc = sh.CreateShortcut(p1)
sc.TargetPath = "wscript.exe"
sc.Arguments = Chr(34) & dstL & Chr(34)
sc.WorkingDirectory = idir
sc.Description = "HaMrex POS"
sc.IconLocation = icoStr
sc.Save
If Err.Number <> 0 Then
    Err.Clear
    Set sc = sh.CreateShortcut(p2)
    sc.TargetPath = "wscript.exe"
    sc.Arguments = Chr(34) & dstL & Chr(34)
    sc.WorkingDirectory = idir
    sc.Description = "HaMrex POS"
    sc.IconLocation = icoStr
    sc.Save
End If
On Error GoTo 0

' Start menu
Dim smDir
smDir = sh.ExpandEnvironmentStrings("%APPDATA%")
smDir = smDir & "\Microsoft\Windows\Start Menu\Programs\HaMrex POS"
MkDir smDir
On Error Resume Next
Set sc = sh.CreateShortcut(smDir & "\HaMrex POS.lnk")
sc.TargetPath = "wscript.exe"
sc.Arguments = Chr(34) & dstL & Chr(34)
sc.WorkingDirectory = idir
sc.IconLocation = icoStr
sc.Save
Set sc = sh.CreateShortcut(smDir & "\Uninstall HaMrex POS.lnk")
sc.TargetPath = uPath
sc.Save
On Error GoTo 0
WScript.Echo "  Shortcuts created."

' Registry
WScript.Echo "  Registering..."
On Error Resume Next
Dim rk
rk = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\HaMrexPOS\"
sh.RegWrite rk & "DisplayName", "HaMrex POS", "REG_SZ"
sh.RegWrite rk & "DisplayVersion", "3.3", "REG_SZ"
sh.RegWrite rk & "Publisher", "Harry Mangulenje", "REG_SZ"
sh.RegWrite rk & "InstallLocation", idir, "REG_SZ"
sh.RegWrite rk & "UninstallString", uPath, "REG_SZ"
sh.RegWrite rk & "DisplayIcon", icoStr, "REG_SZ"
sh.RegWrite rk & "NoModify", 1, "REG_DWORD"
On Error GoTo 0
WScript.Echo "  Registered."

' Save install path for BAT
Dim tf
Set tf = fso.CreateTextFile(sh.ExpandEnvironmentStrings("%TEMP%") & "\hamrex_idir.txt", True)
tf.WriteLine idir
tf.Close

WScript.Echo ""
WScript.Echo "  ============================================"
WScript.Echo "   HaMrex POS v3.3 - Installation Complete!"
WScript.Echo "   Installed : " & idir
WScript.Echo "   Shortcut  : HaMrex POS on Desktop"
WScript.Echo "  ============================================"
WScript.Echo ""
WScript.Quit 0
