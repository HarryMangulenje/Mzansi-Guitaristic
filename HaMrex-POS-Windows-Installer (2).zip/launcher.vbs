Dim sh, fso, hf, dd, br, ok
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
hf = fso.GetParentFolderName(WScript.ScriptFullName)
hf = hf & "\HaMrex-POS.html"
dd = sh.ExpandEnvironmentStrings("%USERPROFILE%")
dd = dd & "\HaMrexPOS"
On Error Resume Next
If Not fso.FolderExists(dd) Then fso.CreateFolder dd
If Not fso.FolderExists(dd & "\backups") Then fso.CreateFolder dd & "\backups"
If Not fso.FolderExists(dd & "\exports") Then fso.CreateFolder dd & "\exports"
On Error GoTo 0
If Not fso.FileExists(hf) Then
    MsgBox "Cannot find HaMrex-POS.html", 16, "HaMrex POS"
    WScript.Quit 1
End If
ok = False
br = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")
br = br & "\Google\Chrome\Application\chrome.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
br = sh.ExpandEnvironmentStrings("%PROGRAMFILES%")
br = br & "\Google\Chrome\Application\chrome.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
br = sh.ExpandEnvironmentStrings("%PROGRAMFILES(X86)%")
br = br & "\Google\Chrome\Application\chrome.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
br = sh.ExpandEnvironmentStrings("%PROGRAMFILES(X86)%")
br = br & "\Microsoft\Edge\Application\msedge.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
br = sh.ExpandEnvironmentStrings("%PROGRAMFILES%")
br = br & "\Microsoft\Edge\Application\msedge.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
br = sh.ExpandEnvironmentStrings("%PROGRAMFILES%")
br = br & "\Mozilla Firefox\firefox.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
br = sh.ExpandEnvironmentStrings("%PROGRAMFILES(X86)%")
br = br & "\Mozilla Firefox\firefox.exe"
If fso.FileExists(br) And Not ok Then
    sh.Run """" & br & """" & " " & """" & hf & """", 1, False
    ok = True
End If
If Not ok Then
    sh.Run "rundll32.exe url.dll,FileProtocolHandler " & hf, 1, False
End If
