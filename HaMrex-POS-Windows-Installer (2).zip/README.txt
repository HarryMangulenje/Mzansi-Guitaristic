HaMrex POS v3.3 - Windows Installer
=====================================
Harry Mangulenje - South Africa

EXTRACT ALL 5 FILES TO THE SAME FOLDER:
  HaMrex-POS-Setup.bat   <- double-click to install
  install.vbs             <- installer engine
  launcher.vbs            <- app launcher
  HaMrex-POS.html         <- the app
  HaMrex.ico.b64          <- app icon

INSTALL: Double-click HaMrex-POS-Setup.bat
USE: Double-click HaMrex POS on Desktop
UNINSTALL: Control Panel > Programs > HaMrex POS
DONATE: harrymangulenje@gmail.com
