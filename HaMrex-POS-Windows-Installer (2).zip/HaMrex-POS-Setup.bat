@echo off
setlocal EnableDelayedExpansion
title HaMrex POS - Setup v3.3
color 0A
echo.
echo  ================================================
echo   HaMrex POS  ^| Installer v3.3
echo   Harry Mangulenje ^| South Africa
echo  ================================================
echo.
set "HERE=%~dp0"
for %%F in (HaMrex-POS.html install.vbs launcher.vbs HaMrex.ico.b64) do (
    if not exist "%HERE%%%F" (
        echo  [ERROR] Missing file: %%F
        echo  Extract ALL files from the ZIP to the same folder.
        pause
        exit /b 1
    )
)
echo  All files found. Installing...
echo.
cscript.exe //NoLogo "%HERE%install.vbs"
if errorlevel 1 (
    echo.
    echo  [ERROR] Installation failed.
    echo  Right-click and Run as Administrator.
    pause
    exit /b 1
)
set "IDIR=%LOCALAPPDATA%\HaMrexPOS"
if exist "%TEMP%\hamrex_idir.txt" (
    set /p IDIR=<"%TEMP%\hamrex_idir.txt"
    del "%TEMP%\hamrex_idir.txt" >nul 2>&1
)
echo.
echo  ============================================
echo   Installation Complete!
echo   Shortcut: HaMrex POS on your Desktop
echo  ============================================
echo.
set /p GO= Launch HaMrex POS now? [Y/N]: 
if /i "!GO!"=="Y" (
    wscript.exe //NoLogo "!IDIR!\HaMrex POS.vbs"
)
echo.
echo  Donate: paypal.me/harrymangulenje
pause
exit /b 0
