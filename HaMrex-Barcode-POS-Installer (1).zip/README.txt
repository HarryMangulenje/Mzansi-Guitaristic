HaMrex Barcode POS v1.0
========================
Harry Mangulenje - South Africa - Freely Distributed

BARCODE SCANNER FEATURES
-------------------------
1. SELL VIEW: Green scanner bar at top
   - Scan any product barcode -> added to cart instantly
   - Scanner auto-redirects here even if focus elsewhere

2. STOCK ENTRY: Scan barcode to auto-select product
   - Open Stock Entry -> scan barcode -> product selected
   - Then enter quantity and save

3. PRODUCT FORM: Scan barcode into the barcode field
   - Click the Scan button to activate capture mode
   - Scan the product -> barcode saved automatically

SCANNER COMPATIBILITY
----------------------
Works with ANY USB or Bluetooth HID barcode scanner
that types characters and presses Enter (standard mode).
Tested pattern: Zebra, Honeywell, Datalogic, etc.

INSTALL
-------
Extract ALL 5 files to the SAME folder:
  HaMrex-Barcode-POS-Setup.bat
  install.vbs
  launcher.vbs
  HaMrex-Barcode-POS.html
  HaMrex.ico.b64

Double-click: HaMrex-Barcode-POS-Setup.bat

DONATE: harrymangulenje@gmail.com
